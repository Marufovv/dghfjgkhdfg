# Portfolio website

Responsive static portfolio with Uzbek, Russian and English translations, theme toggle, projects, timeline and Formspree-ready contact form.

## Customize
Edit profile, project, skills, timeline and translation data in `js/i18n.js`. Replace the avatar in `assets/avatar.svg`; add a personal `assets/CV.pdf` and set `profile.cv` to that path. Replace the Formspree endpoint in `index.html` to enable contact submissions. Social links containing `REPLACE_ME` are intentionally not rendered as links.

## Publish on GitHub Pages
Commit the full folder structure to the repository. In repository Settings → Pages, publish the chosen branch from the root folder.
